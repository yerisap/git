sap.ui.define([
	"synce08/jsonmodel/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
