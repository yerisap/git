sap.ui.define([
	"synce08/exercise8/test/unit/controller/Name.controller"
], function () {
	"use strict";
});
