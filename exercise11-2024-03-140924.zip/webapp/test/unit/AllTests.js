sap.ui.define([
	"synce08/exercise11/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
