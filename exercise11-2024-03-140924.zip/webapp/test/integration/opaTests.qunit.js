/* global QUnit */

sap.ui.require(["sync/e08/exercise11/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
