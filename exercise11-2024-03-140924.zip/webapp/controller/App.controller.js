sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sync.e08.exercise11.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  