sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sync.e08.exercise10.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  