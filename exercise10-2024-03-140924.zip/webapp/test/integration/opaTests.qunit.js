/* global QUnit */

sap.ui.require(["sync/e08/exercise10/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
