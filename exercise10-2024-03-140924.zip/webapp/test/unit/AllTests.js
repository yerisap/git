sap.ui.define([
	"synce08/exercise10/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
